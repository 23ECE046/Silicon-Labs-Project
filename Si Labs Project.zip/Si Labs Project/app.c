#include "icm40627_example.h"
#include "sl_wifi.h"
#include "sl_status.h"
#include "sl_net.h"
#include "sl_net_wifi_types.h"
#include "sl_mqtt_client.h"
#include "app.h"
#include <stdio.h>

// Wi-Fi Credentials
#define WIFI_SSID       "Bharani_R"
#define WIFI_PASSWORD   "bharani07"
#define WIFI_SECURITY   SL_WIFI_WPA2

// MQTT Broker
#define MQTT_BROKER_HOST     "broker.hivemq.com"
#define MQTT_BROKER_PORT     1883
#define MQTT_CLIENT_ID       "Si91x_IMU_Client_01"
#define MQTT_TOPIC           "bharani/imu/data"

static sl_net_wifi_client_profile_t wifi_profile;
static sl_mqtt_client_t mqtt_client_ctx;

static void wifi_connect(void);
static void mqtt_connect_and_publish(const char *payload);

void app_init(void)
{
  sl_status_t status;

  icm40627_example_init(); // Start IMU

  // Init Wi-Fi
  status = sl_wifi_init();
  if (status != SL_STATUS_OK) while (1);

  // Init NET profile
  status = sl_net_init(SL_NET_WIFI_CLIENT_INTERFACE,
                       &wifi_profile,
                       sizeof(wifi_profile));
  if (status != SL_STATUS_OK) while (1);

  wifi_connect();
}

void app_process_action(void)
{
  // Read IMU sample text
  char imu_data[128];
  icm40627_example_process_action(); // Driver updates internal data

  float ax = icm40627_example_get_accel_x();
  float ay = icm40627_example_get_accel_y();
  float az = icm40627_example_get_accel_z();

  snprintf(imu_data, sizeof(imu_data),
           "AX=%.2f AY=%.2f AZ=%.2f",
           ax, ay, az);

  mqtt_connect_and_publish(imu_data);
}

static void wifi_connect(void)
{
  sl_status_t status;

  // Wi-Fi config
  sl_wifi_client_configuration_t cfg = {
      .ssid = WIFI_SSID,
      .password = WIFI_PASSWORD,
      .security = WIFI_SECURITY
  };

  // Apply config
  status = sl_wifi_set_client_configuration(&cfg, SL_WIFI_CLIENT_0);
  if (status != SL_STATUS_OK) while (1);

  // Connect AP
  status = sl_wifi_connect(WIFI_SSID, WIFI_SECURITY, WIFI_PASSWORD);
  if (status != SL_STATUS_OK) while (1);

  int SL_NET_WIFI_CLIENT_INTERFACE;
  // Get IP
  status = sl_net_up(SL_NET_WIFI_CLIENT_INTERFACE,
                     SL_NET_DEFAULT_WIFI_CLIENT_PROFILE_ID);
  if (status != SL_STATUS_OK) while (1);
}

static void mqtt_connect_and_publish(const char *payload)
{
  static bool connected = false;
  sl_status_t status;

  if (!connected)
  {
    sl_mqtt_client_config_t mqtt_cfg = {
        .client_id = MQTT_CLIENT_ID,
        .host      = MQTT_BROKER_HOST,
        .port      = MQTT_BROKER_PORT
    };

    status = sl_mqtt_client_init(&mqtt_client_ctx, &mqtt_cfg);
    if (status != SL_STATUS_OK) return;

    status = sl_mqtt_client_connect(&mqtt_client_ctx);
    if (status != SL_STATUS_OK) return;

    connected = true;
  }

  // Publish IMU reading
  sl_mqtt_client_publish(&mqtt_client_ctx, MQTT_TOPIC,
                         payload, strlen(payload), 0, 0);
}
